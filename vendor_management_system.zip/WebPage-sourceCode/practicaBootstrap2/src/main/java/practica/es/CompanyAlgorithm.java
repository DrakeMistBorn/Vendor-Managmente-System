package practica.es;

import java.util.Collections;
import java.util.List;

public class CompanyAlgorithm {
    private final int data_risk;
    private final float total_incomes;
    private final float cybersecurity_investment;
    private final Company company;

    public CompanyAlgorithm(Company company){
        this.data_risk = company.getData_risk();
        this.total_incomes = company.getAnnual_revenue();
        this.cybersecurity_investment = company.getCybersecurity_investment();
        this.company = company;
    }
    
    public String[] analyze_data(){
        int ideal_investment_percentage = define_investment_percentage(data_risk);
        float ideal_cybersecurity_investment = (ideal_investment_percentage * total_incomes)/100;
        List<String> changes;
        if (this.cybersecurity_investment < ideal_cybersecurity_investment){
            float actual_investment_percentage;
            
            if (this.cybersecurity_investment != 0 ) {
                actual_investment_percentage =(float) (this.cybersecurity_investment/this.total_incomes)*100;
            }else{actual_investment_percentage = 0;}
            
            System.out.println("Data risk: "+this.data_risk+" Total incomes: "+this.total_incomes+" cybersecurity investment: "+this.cybersecurity_investment+" idel investment "+
            ideal_cybersecurity_investment+" "+ideal_investment_percentage+" actual investment percentage "+actual_investment_percentage);
            
            changes = get_possible_improvements(ideal_investment_percentage - actual_investment_percentage);
        }
        else{changes = new java.util.ArrayList<>(Collections.emptyList());}
        String[] array_changes = new String[changes.size()];
        int i;
        for (i=0; i<changes.size() ;i++) {
        	array_changes[i]= changes.get(i);
        }
        return array_changes;
    }

    public int define_investment_percentage(int company_type){
        switch (company_type){
            case 3: return 26;
            case 2: return 19;
            default: return 13;
        }
    }

    public boolean is_not_best_antivirus(){
        return company.getAntivirus_id() != IdealDataValue.getAntivirus();
    }

    public boolean is_not_enough_audits(){
        return company.getNumber_audits() != IdealDataValue.getAudit_number();
    }

    public List<String> get_possible_improvements(float percentage_budget){
        List<String> improvements = new java.util.ArrayList<>(Collections.emptyList());
        double cost = IdealDataValue.get_contingency_plan_cost();
        if (!company.isContingency_plan() && percentage_budget > cost) {
            percentage_budget = (float) (percentage_budget - cost);
            improvements.add("A contingency plan - in case an attack occurs the company would be able to fix it with less public damage and faster. The cost should be a "+cost+"% of the investment in security");
        }
        cost = IdealDataValue.get_isolated_backups_cost();
        if (!company.isIsolated_backups() && percentage_budget > cost){
            percentage_budget = (float) (percentage_budget - cost);
            improvements.add("Frequently isolated backups - if for some reason the company lost its data because, for example, a problem with a server, it is easy to recover from the last backup. The cost should be a "+cost+"% of the investment in security");
        }
        cost = IdealDataValue.get_antivirus_cost();
        if (is_not_best_antivirus() && percentage_budget > cost){
            percentage_budget = (float) (percentage_budget - cost);
            improvements.add("Adquire a better antivirus - we recommend you McAfee. The cost should be a "+cost+"% of the investment in security");
        }
        cost = IdealDataValue.get_ciphered_communication_cost();
        if (!company.isCiphered_communications() && percentage_budget > cost){
            percentage_budget = (float) (percentage_budget - cost);
            improvements.add("Ciphered communications - protects your data much better. The cost should be a "+cost+"% of the investment in security");
        }
        cost = IdealDataValue.get_audit_number_cost();
        if (is_not_enough_audits() && percentage_budget > cost){
            percentage_budget = (float) (percentage_budget - cost);
            improvements.add("Increase the number of audits to at least 3. The cost should be a "+cost+"% of the investment in security");
        }
        cost = IdealDataValue.get_two_factor_authentication_cost();
        if (!company.isTwo_factor_authentication() && percentage_budget > cost){
            percentage_budget = (float) (percentage_budget - cost);
            improvements.add("Two factor authentication - make the attackers really hard to enter in your system when a physing attack occurs. The cost should be a "+cost+"% of the investment in security");
        }
        cost = IdealDataValue.get_cybercrisis_team_cost();
        if (!company.isCiphered_communications() && percentage_budget > cost){
            percentage_budget = (float) (percentage_budget - cost);
            improvements.add("Cybercrisis team - the team that will solve an attack problem as fast as possible and minimizing the damage. The cost should be a "+cost+"% of the investment in security");
        }
        improvements.add("Reduce supplying vendors number - with less suplying vendors less risk of an attack in the supplying vendor chain");
        System.out.println("Still left "+percentage_budget+"% of the budget");
        return improvements;
    }

    public float company_risk_percentage(){
        int risk = 0;
        if (!company.isContingency_plan()){
            risk = risk + 20;
        }
        if (!company.isIsolated_backups()){
            risk = risk + 20;
        }
        if (is_not_best_antivirus()){
            risk = risk + 20;
        }
        if (!company.isCiphered_communications()){
            risk = risk + 14;
        }
        if (is_not_enough_audits()){
            risk = risk + 14;
        }
        if (company.isTwo_factor_authentication()){
            risk = risk + 6;
        }
        if (company.isCybercrisis_team()){
            risk = risk + 6;
        }
        return risk;
    }

    public static class IdealDataValue {
        // High-importance
        private static int audit_number;
        private static int antivirus;


        public IdealDataValue(){
            audit_number = 3;
            antivirus = 0;
        }

        public  static int getAudit_number(){
            return audit_number;
        }

        public static int getAntivirus() {
            return antivirus;
        }

        public  static double get_contingency_plan_cost(){
            return 2;
        }

        public static  double get_isolated_backups_cost(){
            return 8;
        }

        public  static double get_antivirus_cost(){
            return 4;
        }

        public  static double get_ciphered_communication_cost(){
            return 8;
        }

        public  static double get_audit_number_cost() {
            return 4;
        }

        public  static double get_two_factor_authentication_cost(){
            return 2;
        }

        public  static double get_cybercrisis_team_cost(){
            return 15;
        }
    }
}
