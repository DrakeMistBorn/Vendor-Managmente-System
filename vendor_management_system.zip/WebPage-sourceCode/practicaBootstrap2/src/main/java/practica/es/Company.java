package practica.es;

import java.sql.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "company")
public class Company {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String company_name;
	private String crypto_mechanism;
	private Date company_data_update;
	private Date product_update;
	private int employee_awareness;
	private int number_employees;
	private int annual_revenue;
	private int cybersecurity_investment;
	private int number_devices;
	private int number_audits;
	private boolean cybercrisis_team;
	private boolean contingency_plan;
	private boolean signed_cyber_requirements;
	private boolean ciphered_communications;
	private boolean role_validator;
	private Long antivirus_id;
	private boolean two_factor_authentication;
	private boolean isolated_backups;
	private int data_risk;
	private int supplying_vendors;
	
	
	public Company(Long id, String company_name, String crypto_mechanism, Date company_data_update,
			Date product_update, int employee_awareness, int number_employees, int annual_revenue,
			int cybersecurity_investment, int number_devices, int number_audits, boolean cybercrisis_team,
			boolean contingency_plan, boolean signed_cyber_requirements, boolean ciphered_communications,
			boolean role_validator, Long antivirus_id, boolean two_factor_authentication, boolean isolated_backups,
			int data_risk, int supplying_vendors) {
		super();
		this.id = id;
		this.company_name = company_name;
		this.crypto_mechanism = crypto_mechanism;
		this.company_data_update = company_data_update;
		this.product_update = product_update;
		this.employee_awareness = employee_awareness;
		this.number_employees = number_employees;
		this.annual_revenue = annual_revenue;
		this.cybersecurity_investment = cybersecurity_investment;
		this.number_devices = number_devices;
		this.number_audits = number_audits;
		this.cybercrisis_team = cybercrisis_team;
		this.contingency_plan = contingency_plan;
		this.signed_cyber_requirements = signed_cyber_requirements;
		this.ciphered_communications = ciphered_communications;
		this.role_validator = role_validator;
		this.antivirus_id = antivirus_id;
		this.two_factor_authentication = two_factor_authentication;
		this.isolated_backups = isolated_backups;
		this.data_risk = data_risk;
		this.supplying_vendors = supplying_vendors;
	}
	
	
	
	public Company(String company_name, String crypto_mechanism, Date company_data_update, Date product_update,
			int employee_awareness, int number_employees, int annual_revenue, int cybersecurity_investment,
			int number_devices, int number_audits, boolean cybercrisis_team, boolean contingency_plan,
			boolean signed_cyber_requirements, boolean ciphered_communications, boolean role_validator,
			Long antivirus_id, boolean two_factor_authentication, boolean isolated_backups, int data_risk, int supplying_vendors) {
		super();
		this.company_name = company_name;
		this.crypto_mechanism = crypto_mechanism;
		this.company_data_update = company_data_update;
		this.product_update = product_update;
		this.employee_awareness = employee_awareness;
		this.number_employees = number_employees;
		this.annual_revenue = annual_revenue;
		this.cybersecurity_investment = cybersecurity_investment;
		this.number_devices = number_devices;
		this.number_audits = number_audits;
		this.cybercrisis_team = cybercrisis_team;
		this.contingency_plan = contingency_plan;
		this.signed_cyber_requirements = signed_cyber_requirements;
		this.ciphered_communications = ciphered_communications;
		this.role_validator = role_validator;
		this.antivirus_id = antivirus_id;
		this.two_factor_authentication = two_factor_authentication;
		this.isolated_backups = isolated_backups;
		this.data_risk = data_risk;
		this.supplying_vendors = supplying_vendors;
	}



	public Company() {
		
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getCrypto_mechanism() {
		return crypto_mechanism;
	}
	public void setCrypto_mechanism(String crypto_mechanism) {
		this.crypto_mechanism = crypto_mechanism;
	}
	public Date getCompany_data_update() {
		return company_data_update;
	}
	public void setCompany_data_update(Date company_data_update) {
		this.company_data_update = company_data_update;
	}
	public Date getProduct_update() {
		return product_update;
	}
	public void setProduct_update(Date product_update) {
		this.product_update = product_update;
	}
	public int getEmployee_awareness() {
		return employee_awareness;
	}
	public void setEmployee_awareness(int employee_awareness) {
		this.employee_awareness = employee_awareness;
	}
	public int getNumber_employees() {
		return number_employees;
	}
	public void setNumber_employees(int number_employees) {
		this.number_employees = number_employees;
	}
	public int getAnnual_revenue() {
		return annual_revenue;
	}
	public void setAnnual_revenue(int annual_revenue) {
		this.annual_revenue = annual_revenue;
	}
	public int getCybersecurity_investment() {
		return cybersecurity_investment;
	}
	public void setCybersecurity_investment(int cybersecurity_investment) {
		this.cybersecurity_investment = cybersecurity_investment;
	}
	public int getNumber_devices() {
		return number_devices;
	}
	public void setNumber_devices(int number_devices) {
		this.number_devices = number_devices;
	}
	public int getNumber_audits() {
		return number_audits;
	}
	public void setNumber_audits(int number_audits) {
		this.number_audits = number_audits;
	}
	public boolean isCybercrisis_team() {
		return cybercrisis_team;
	}
	public void setCybercrisis_team(boolean cybercrisis_team) {
		this.cybercrisis_team = cybercrisis_team;
	}
	public boolean isContingency_plan() {
		return contingency_plan;
	}
	public void setContingency_plan(boolean contingency_plan) {
		this.contingency_plan = contingency_plan;
	}
	public boolean isSigned_cyber_requirements() {
		return signed_cyber_requirements;
	}
	public void setSigned_cyber_requirements(boolean signed_cyber_requirements) {
		this.signed_cyber_requirements = signed_cyber_requirements;
	}
	public boolean isCiphered_communications() {
		return ciphered_communications;
	}
	public void setCiphered_communications(boolean ciphered_communications) {
		this.ciphered_communications = ciphered_communications;
	}
	public boolean isRole_validator() {
		return role_validator;
	}
	public void setRole_validator(boolean role_validator) {
		this.role_validator = role_validator;
	}
	public Long getAntivirus_id() {
		return antivirus_id;
	}
	public void setAntivirus_id(Long antivirus_id) {
		this.antivirus_id = antivirus_id;
	}
	public boolean isTwo_factor_authentication() {
		return two_factor_authentication;
	}
	public void setTwo_factor_authentication(boolean two_factor_authentication) {
		this.two_factor_authentication = two_factor_authentication;
	}
	public boolean isIsolated_backups() {
		return isolated_backups;
	}
	public void setIsolated_backups(boolean isolated_backups) {
		this.isolated_backups = isolated_backups;
	}
	public int getData_risk() {
		return data_risk;
	}
	public void setData_risk(int data_risk) {
		this.data_risk = data_risk;
	}
	public int getSupplying_vendors() {
		return supplying_vendors;
	}
	public void setSupplying_vendors(int supplying_vendors) {
		this.supplying_vendors = supplying_vendors;
	}



	@Override
	public String toString() {
		return "Company [id=" + id + ", company_name=" + company_name + ", crypto_mechanism="
				+ crypto_mechanism + ", company_data_update=" + company_data_update + ", product_update="
				+ product_update + ", employee_awareness=" + employee_awareness + ", number_employees="
				+ number_employees + ", annual_revenue=" + annual_revenue + ", cybersecurity_investment="
				+ cybersecurity_investment + ", number_devices=" + number_devices + ", number_audits=" + number_audits
				+ ", cybercrisis_team=" + cybercrisis_team + ", contingency_plan=" + contingency_plan
				+ ", signed_cyber_requirements=" + signed_cyber_requirements + ", ciphered_communications="
				+ ciphered_communications + ", role_validator=" + role_validator + ", antivirus_id=" + antivirus_id
				+ ", two_factor_authentication=" + two_factor_authentication + ", isolated_backups=" + isolated_backups
				+ ", data_risk=" + data_risk + ", supplying_vendors=" + supplying_vendors + "]";
	}
}
