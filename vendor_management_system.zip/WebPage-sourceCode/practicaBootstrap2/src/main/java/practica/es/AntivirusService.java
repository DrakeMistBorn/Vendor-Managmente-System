package practica.es;

import java.util.Collection;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
 
@Service
public class AntivirusService {
	
	
	
	@Autowired
	private AntivirusRepository antivirusRepository;
	
	public Collection<Antivirus> showAntivirus(){
		return antivirusRepository.findAll(Sort.by(Sort.Direction.DESC,"idantivirus"));
	}
	
	
}
