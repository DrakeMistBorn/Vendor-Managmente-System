package practica.es;

import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

@Service
public class CompanyService {
	
	@Autowired
	private CompanyRepository companyRepository;
	 
	
	public Collection<Company> showCompanies(){
		return companyRepository.findAll(Sort.by(Sort.Direction.DESC,"id"));
	}
	
	public String addToModelIndex(Model model, Collection<Antivirus> antivirus) { //add Item collection to model to be seen in the Index
		model.addAttribute("antivirus", antivirus);
		model.addAttribute("percentage", "");
		model.addAttribute("analysis", "");
		return "index";
	}
	public String addToModelAData(Model model , String[] analysis, float percentage) { //add Item collection to model to be seen in the Index
		model.addAttribute("percentage", percentage);
		model.addAttribute("analysis", analysis);
		return "index";
	}
	
	public void postCompany(Company company) {
		companyRepository.save(company);
	}

	public Company getCompany(Long id) {
		return companyRepository.getOne(id);
	}


	
	
}
