package practica.es;

import java.sql.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class CompanyController {

	@Autowired
	private CompanyService companyService;	
	 
	@Autowired
	private AntivirusService antivirusService;
	
	@RequestMapping("/")
	public String  showCompanies(Model model) {
		return companyService.addToModelIndex(model, antivirusService.showAntivirus());
		
	}
	
	@RequestMapping ("/form/post")
	public String formPostCompany(Model model, @RequestParam String company_name, @RequestParam String crypto_mechanism, @RequestParam Date company_data_update,
		   @RequestParam Date product_update, @RequestParam int employee_awareness, @RequestParam int number_employees, @RequestParam int annual_revenue,
		   @RequestParam int cybersecurity_investment, @RequestParam int number_devices, @RequestParam int number_audits, @RequestParam String cybercrisis_team,
		   @RequestParam String contingency_plan, @RequestParam String signed_cyber_requirements, @RequestParam String ciphered_communications, 
		   @RequestParam String role_validator, @RequestParam Long antivirus_id, @RequestParam String two_factor_authentication, @RequestParam String isolated_backups,
		   @RequestParam int data_risk, @RequestParam int supplying_vendors) {
		System.out.println(cybercrisis_team+", "+contingency_plan+", "+signed_cyber_requirements+", "+ciphered_communications+", "+role_validator);
		boolean cybercrisis_team_bool;
		if (cybercrisis_team.equals("true")) {
			cybercrisis_team_bool=true;
		}else {
			cybercrisis_team_bool=false;
		}
		
		boolean contingency_plan_bool;
		if (contingency_plan.equals("true")) {
			contingency_plan_bool=true;
		}else {
			contingency_plan_bool=false;
		}
		
		boolean signed_cyber_requirements_bool;
		if (signed_cyber_requirements.equals("true")) {
			signed_cyber_requirements_bool=true;
		}else {
			signed_cyber_requirements_bool=false;
		}
		
		boolean ciphered_communications_bool;
		if (ciphered_communications.equals("true")) {
			ciphered_communications_bool=true;
		}else {
			ciphered_communications_bool=false;
		}
		
		boolean role_validator_bool;
		if (role_validator.equals("true")) {
			role_validator_bool=true;
		}else {
			role_validator_bool=false;
		}
		
		boolean two_factor_authentication_bool;
		if (two_factor_authentication.equals("true")) {
			two_factor_authentication_bool=true;
		}else {
			two_factor_authentication_bool=false;
		}
		
		boolean isolated_backups_bool;
		if (cybercrisis_team.equals("true")) {
			isolated_backups_bool=true;
		}else {
			isolated_backups_bool=false;
		}
		
		Company company = new Company(company_name, crypto_mechanism, company_data_update,
				   product_update, employee_awareness, number_employees, annual_revenue,
				   cybersecurity_investment, number_devices, number_audits, cybercrisis_team_bool, 
				   contingency_plan_bool, signed_cyber_requirements_bool, ciphered_communications_bool, 
				   role_validator_bool, antivirus_id, two_factor_authentication_bool, isolated_backups_bool, 
				   data_risk, supplying_vendors);
		
		companyService.postCompany(company);
		CompanyAlgorithm companyAlgorithm = new CompanyAlgorithm(company);
		String [] dataAnalysis = companyAlgorithm.analyze_data();
		return companyService.addToModelAData(model, dataAnalysis, companyAlgorithm.company_risk_percentage());	
	}
	
}
