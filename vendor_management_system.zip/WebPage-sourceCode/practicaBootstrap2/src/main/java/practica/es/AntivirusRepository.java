package practica.es;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AntivirusRepository extends JpaRepository<Antivirus, Long>{
 
}
