package practica.es;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
 
@Entity
@Table(name = "antivirus")
public class Antivirus {
	 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idantivirus;
	
	private String antivirus_name;
	private int overall_efficacy;
	private int user_mark;
	private int price;
	
	

	public Antivirus(Long idAntivirus, String antivirus_name, int overall_efficacy, int user_mark, int price) {
		super();
		this.idantivirus = idAntivirus;
		this.antivirus_name = antivirus_name;
		this.overall_efficacy = overall_efficacy;
		this.user_mark = user_mark;
		this.price = price;
	}
	
	public Antivirus(String antivirus_name, int overall_efficacy, int user_mark, int price) {
		super();
		this.antivirus_name = antivirus_name;
		this.overall_efficacy = overall_efficacy;
		this.user_mark = user_mark;
		this.price = price;
	}
	
	public Antivirus() {
		
	}

	public Long getIdAntivirus() {
		return idantivirus;
	}
	public void setIdAntivirus(Long idAntivirus) {
		this.idantivirus = idAntivirus;
	}
	public String getAntivirus_name() {
		return antivirus_name;
	}
	public void setAntivirus_name(String antivirus_name) {
		this.antivirus_name = antivirus_name;
	}
	public int getOverall_efficacy() {
		return overall_efficacy;
	}
	public void setOverall_efficacy(int overall_efficacy) {
		this.overall_efficacy = overall_efficacy;
	}
	public int getUser_mark() {
		return user_mark;
	}
	public void setUser_mark(int user_mark) {
		this.user_mark = user_mark;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Antivirus [idAntivirus=" + idantivirus + ", antivirus_name=" + antivirus_name + ", overall_efficacy="
				+ overall_efficacy + ", user_mark=" + user_mark + ", price=" + price + "]";
	}
}
